intence, the scrolling indicator
================================

intence replaces a scrollbar with a texture

see http://asvd.github.io/intence/ for the concept description and
usage guide

-

Follow me on twitter: https://twitter.com/asvd0

